"""
Synchronous clock model for the digital stopwatch.
One clock cycle represents 10 milliseconds.
"""


class Clock:
    def __init__(self, period_ms=10):
        self.period_ms = period_ms
        self.cycle = 0

    def rising_edge(self):
        self.cycle += 1
        return self.cycle

    def reset(self):
        self.cycle = 0

    @property
    def time_seconds(self):
        return self.cycle * self.period_ms / 1000.0
