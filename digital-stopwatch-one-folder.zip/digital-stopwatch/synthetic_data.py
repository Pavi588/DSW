"""Generate reproducible synthetic stopwatch timing data."""

from pathlib import Path

import numpy as np
import pandas as pd


SEED = 2201
SAMPLES = 1000
OUTPUT_FILE = Path("synthetic_clock_data.csv")


def generate_data(samples=SAMPLES, seed=SEED):
    rng = np.random.default_rng(seed)

    clock_cycle = np.arange(samples)
    ideal_time = clock_cycle * 0.01

    timing_jitter = rng.normal(
        loc=0.0,
        scale=0.0005,
        size=samples
    )

    actual_time = ideal_time + timing_jitter
    timing_error = actual_time - ideal_time

    return pd.DataFrame({
        "clock_cycle": clock_cycle,
        "ideal_time_sec": ideal_time,
        "actual_time_sec": actual_time,
        "timing_error_sec": timing_error,
    })


if __name__ == "__main__":
    data = generate_data()
    data.to_csv(OUTPUT_FILE, index=False)

    print("Synthetic data generated successfully.")
    print(f"Seed: {SEED}")
    print(f"Samples: {SAMPLES}")
    print(f"Output: {OUTPUT_FILE}")
    print("\nFirst 10 rows:")
    print(data.head(10))
