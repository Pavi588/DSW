"""Cascaded BCD counters for MM:SS:CS."""


class BCDDigit:
    def __init__(self, maximum):
        self.maximum = maximum
        self.value = 0

    def reset(self):
        self.value = 0

    def tick(self):
        if self.value >= self.maximum:
            self.value = 0
            return True

        self.value += 1
        return False


class CascadedBCDCounter:
    def __init__(self):
        self.cs_units = BCDDigit(9)
        self.cs_tens = BCDDigit(9)
        self.sec_units = BCDDigit(9)
        self.sec_tens = BCDDigit(5)
        self.min_units = BCDDigit(9)
        self.min_tens = BCDDigit(9)

    def reset(self):
        for digit in (
            self.cs_units,
            self.cs_tens,
            self.sec_units,
            self.sec_tens,
            self.min_units,
            self.min_tens,
        ):
            digit.reset()

    def tick(self):
        carry = self.cs_units.tick()
        if not carry:
            return

        carry = self.cs_tens.tick()
        if not carry:
            return

        carry = self.sec_units.tick()
        if not carry:
            return

        carry = self.sec_tens.tick()
        if not carry:
            return

        carry = self.min_units.tick()
        if not carry:
            return

        self.min_tens.tick()

    def get_time(self):
        minutes = self.min_tens.value * 10 + self.min_units.value
        seconds = self.sec_tens.value * 10 + self.sec_units.value
        centiseconds = self.cs_tens.value * 10 + self.cs_units.value
        return minutes, seconds, centiseconds

    def display(self):
        minutes, seconds, centiseconds = self.get_time()
        return f"{minutes:02d}:{seconds:02d}:{centiseconds:02d}"

    def state(self):
        return {
            "Minute Tens": self.min_tens.value,
            "Minute Units": self.min_units.value,
            "Second Tens": self.sec_tens.value,
            "Second Units": self.sec_units.value,
            "Centisecond Tens": self.cs_tens.value,
            "Centisecond Units": self.cs_units.value,
        }
