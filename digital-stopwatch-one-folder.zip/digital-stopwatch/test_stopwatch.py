"""Test suite for the synchronous digital stopwatch."""

from stopwatch import DigitalStopwatch


def new_stopwatch():
    return DigitalStopwatch()


def start_stopwatch(sw):
    sw.start()
    sw.rising_edge()


def run_cycles(sw, number):
    for _ in range(number):
        sw.rising_edge()


def test_01_initial_state():
    sw = new_stopwatch()
    assert sw.display == "00:00:00"
    assert sw.state.name == "IDLE"


def test_02_start():
    sw = new_stopwatch()
    start_stopwatch(sw)
    assert sw.state.name == "RUNNING"


def test_03_one_centisecond():
    sw = new_stopwatch()
    start_stopwatch(sw)
    run_cycles(sw, 1)
    assert sw.display == "00:00:01"


def test_04_ten_centiseconds():
    sw = new_stopwatch()
    start_stopwatch(sw)
    run_cycles(sw, 10)
    assert sw.display == "00:00:10"


def test_05_one_second():
    sw = new_stopwatch()
    start_stopwatch(sw)
    run_cycles(sw, 100)
    assert sw.display == "00:01:00"


def test_06_one_minute():
    sw = new_stopwatch()
    start_stopwatch(sw)
    run_cycles(sw, 6000)
    assert sw.display == "01:00:00"


def test_07_one_point_five_seconds():
    sw = new_stopwatch()
    start_stopwatch(sw)
    run_cycles(sw, 150)
    assert sw.display == "00:01:50"


def test_08_nine_point_nine_nine_seconds():
    sw = new_stopwatch()
    start_stopwatch(sw)
    run_cycles(sw, 999)
    assert sw.display == "00:09:99"


def test_09_twelve_point_three_four_seconds():
    sw = new_stopwatch()
    start_stopwatch(sw)
    run_cycles(sw, 1234)
    assert sw.display == "00:12:34"


def test_10_stop():
    sw = new_stopwatch()
    start_stopwatch(sw)
    run_cycles(sw, 100)

    saved_time = sw.display

    sw.stop()
    sw.rising_edge()
    run_cycles(sw, 100)

    assert sw.display == saved_time
    assert sw.state.name == "PAUSED"


def test_11_stop_while_idle():
    sw = new_stopwatch()
    sw.stop()
    sw.rising_edge()

    assert sw.state.name == "IDLE"
    assert sw.display == "00:00:00"


def test_12_reset_while_running():
    sw = new_stopwatch()
    start_stopwatch(sw)
    run_cycles(sw, 500)

    sw.reset()
    sw.rising_edge()

    assert sw.state.name == "IDLE"
    assert sw.display == "00:00:00"


def test_13_start_while_running():
    sw = new_stopwatch()
    start_stopwatch(sw)
    run_cycles(sw, 100)

    sw.start()
    sw.rising_edge()

    assert sw.state.name == "RUNNING"
    assert sw.display == "00:02:00"


def test_14_pause_and_resume():
    sw = new_stopwatch()
    start_stopwatch(sw)
    run_cycles(sw, 100)

    sw.stop()
    sw.rising_edge()

    paused_time = sw.display

    run_cycles(sw, 100)

    assert sw.display == paused_time

    sw.start()
    sw.rising_edge()
    run_cycles(sw, 100)

    assert sw.display == "00:03:00"
    assert sw.state.name == "RUNNING"


def test_15_counter_rollover():
    sw = new_stopwatch()
    start_stopwatch(sw)
    run_cycles(sw, 6000)

    assert sw.display == "01:00:00"


def run_all_tests():
    tests = [
        test_01_initial_state,
        test_02_start,
        test_03_one_centisecond,
        test_04_ten_centiseconds,
        test_05_one_second,
        test_06_one_minute,
        test_07_one_point_five_seconds,
        test_08_nine_point_nine_nine_seconds,
        test_09_twelve_point_three_four_seconds,
        test_10_stop,
        test_11_stop_while_idle,
        test_12_reset_while_running,
        test_13_start_while_running,
        test_14_pause_and_resume,
        test_15_counter_rollover,
    ]

    passed = 0

    print("=" * 65)
    print("DIGITAL STOPWATCH TEST RESULTS")
    print("=" * 65)

    for number, test in enumerate(tests, start=1):
        try:
            test()
            print(f"TC{number:02d} PASS - {test.__name__}")
            passed += 1
        except AssertionError:
            print(f"TC{number:02d} FAIL - {test.__name__}")

    print("=" * 65)
    print(f"RESULT: {passed}/{len(tests)} TESTS PASSED")
    print("=" * 65)

    return passed == len(tests)


if __name__ == "__main__":
    if not run_all_tests():
        raise SystemExit(1)
