"""Streamlit web interface for the digital stopwatch."""

import time
import streamlit as st

from stopwatch import DigitalStopwatch


st.set_page_config(
    page_title="Digital Stopwatch",
    page_icon="⏱️",
    layout="wide"
)

if "stopwatch" not in st.session_state:
    st.session_state.stopwatch = DigitalStopwatch()

if "automatic_clock" not in st.session_state:
    st.session_state.automatic_clock = False

sw = st.session_state.stopwatch

st.markdown(
    """
    <style>
    .main-title {
        text-align: center;
        font-size: 45px;
        font-weight: bold;
    }
    .subtitle {
        text-align: center;
        font-size: 18px;
        margin-bottom: 30px;
    }
    .display {
        text-align: center;
        font-family: monospace;
        font-size: 80px;
        font-weight: bold;
        padding: 35px;
        border-radius: 20px;
        border: 3px solid #555;
        margin: 20px 0;
    }
    .state {
        text-align: center;
        font-size: 28px;
        font-weight: bold;
        padding: 15px;
        border-radius: 12px;
        border: 2px solid #777;
    }
    </style>
    """,
    unsafe_allow_html=True
)

st.markdown(
    '<div class="main-title">⏱️ Digital Stopwatch</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="subtitle">Synchronous Sequential Logic — EC2201 Digital Electronics</div>',
    unsafe_allow_html=True
)

st.sidebar.title("🎛️ Control Panel")

if st.sidebar.button("▶ START", use_container_width=True):
    sw.start()
    sw.rising_edge()
    st.rerun()

if st.sidebar.button("⏸ STOP", use_container_width=True):
    sw.stop()
    sw.rising_edge()
    st.rerun()

if st.sidebar.button("🔄 RESET", use_container_width=True):
    sw.reset()
    sw.rising_edge()
    st.session_state.automatic_clock = False
    st.rerun()

st.sidebar.divider()

st.session_state.automatic_clock = st.sidebar.checkbox(
    "⏱️ Automatic Clock",
    value=st.session_state.automatic_clock
)

st.markdown(
    f'<div class="display">{sw.display}</div>',
    unsafe_allow_html=True
)

col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("### FSM State")
    st.markdown(
        f'<div class="state">{sw.state.name}</div>',
        unsafe_allow_html=True
    )

with col2:
    st.metric("Clock Cycles", sw.clock.cycle)

with col3:
    st.metric("Simulated Time", f"{sw.clock.time_seconds:.2f} s")

st.divider()

st.header("🔌 Synchronous Sequential Circuit")

st.code(
    """
                    MASTER CLOCK
                         |
                         v
                +----------------+
                |      FSM       |
                | IDLE/RUNNING   |
                |     /PAUSED    |
                +-------+--------+
                        |
                     ENABLE
                        |
                        v
                +----------------+
                |  BCD COUNTERS  |
                | CS -> SEC -> MIN|
                +-------+--------+
                        |
                        v
                     MM:SS:CS
    """,
    language="text"
)

st.header("🔢 Internal BCD Counter State")

counter_state = sw.counter.state()
counter_columns = st.columns(6)

for column, (name, value) in zip(counter_columns, counter_state.items()):
    with column:
        st.metric(name, value)

st.header("🔄 FSM State Transition Table")

st.table({
    "Current State": ["IDLE", "RUNNING", "PAUSED"],
    "START": ["RUNNING", "RUNNING", "RUNNING"],
    "STOP": ["IDLE", "PAUSED", "PAUSED"],
    "RESET": ["IDLE", "IDLE", "IDLE"],
})

st.header("📘 How the Circuit Works")

st.markdown(
    """
**IDLE:** Waiting for START.

**RUNNING:** BCD counters increment on each rising edge.

**PAUSED:** Counter value is retained.

**RESET:** Clears counters and returns the FSM to IDLE.

One simulated clock cycle = 10 ms.

- 100 cycles = 1 second
- 6000 cycles = 1 minute
"""
)

if st.session_state.automatic_clock and sw.running:
    time.sleep(0.01)
    sw.rising_edge()
    st.rerun()

st.divider()

st.caption(
    "EC2201 Digital Electronics Project | "
    "Digital Stopwatch using Synchronous Sequential Logic"
)
