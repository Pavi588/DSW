# Digital Stopwatch Using Synchronous Sequential Logic

## EC2201 Digital Electronics Project

A Python/Streamlit simulation of a digital stopwatch using synchronous sequential logic.

## Files

- `app.py` - Streamlit web interface
- `stopwatch.py` - Main synchronous stopwatch controller
- `clock.py` - Synchronous clock model
- `counters.py` - Cascaded BCD counters
- `fsm.py` - Finite State Machine
- `test_stopwatch.py` - 15 test cases
- `synthetic_data.py` - Reproducible timing dataset generator
- `requirements.txt` - Python dependencies
- `.gitignore` - Git ignore rules
- `LICENSE` - MIT License

## Architecture

```text
MASTER CLOCK
     |
     v
    FSM
     |
     v
COUNTER ENABLE
     |
     v
Cascaded BCD Counters
     |
     v
  MM:SS:CS
```

## FSM States

- IDLE
- RUNNING
- PAUSED

RESET from any state returns to IDLE.

## Clock

One simulated clock cycle represents 10 ms.

- 100 cycles = 1 second
- 6000 cycles = 1 minute

## Installation

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

Linux/macOS:

```bash
source venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## Run Tests

```bash
python test_stopwatch.py
```

or:

```bash
pytest
```

Expected result:

```text
RESULT: 15/15 TESTS PASSED
```

## Run Web Application

```bash
streamlit run app.py
```

## Generate Synthetic Data

```bash
python synthetic_data.py
```

This creates `synthetic_clock_data.csv` using fixed seed `2201`.

## Counter Rollover

```text
00:00:99 -> 00:01:00
00:59:99 -> 01:00:00
```
