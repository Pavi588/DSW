"""Finite State Machine for the synchronous digital stopwatch."""

from enum import Enum


class FSMState(Enum):
    IDLE = 0
    RUNNING = 1
    PAUSED = 2


class StopwatchFSM:
    def __init__(self):
        self.state = FSMState.IDLE

    def next_state(self, start=False, stop=False, reset=False):
        if reset:
            return FSMState.IDLE

        if self.state == FSMState.IDLE:
            return FSMState.RUNNING if start else FSMState.IDLE

        if self.state == FSMState.RUNNING:
            return FSMState.PAUSED if stop else FSMState.RUNNING

        if self.state == FSMState.PAUSED:
            return FSMState.RUNNING if start else FSMState.PAUSED

        return FSMState.IDLE

    def update(self, start=False, stop=False, reset=False):
        self.state = self.next_state(start, stop, reset)
        return self.state

    def reset(self):
        self.state = FSMState.IDLE

    @property
    def running(self):
        return self.state == FSMState.RUNNING
