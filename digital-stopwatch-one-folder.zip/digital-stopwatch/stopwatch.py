"""Top-level synchronous digital stopwatch."""

from clock import Clock
from counters import CascadedBCDCounter
from fsm import StopwatchFSM


class DigitalStopwatch:
    def __init__(self):
        self.clock = Clock(period_ms=10)
        self.fsm = StopwatchFSM()
        self.counter = CascadedBCDCounter()

        self.pending_start = False
        self.pending_stop = False
        self.pending_reset = False

    def start(self):
        self.pending_start = True

    def stop(self):
        self.pending_stop = True

    def reset(self):
        self.pending_reset = True

    def rising_edge(self):
        if self.pending_reset:
            self.fsm.update(reset=True)
            self.counter.reset()
            self.clock.reset()
            self.clear_inputs()
            return self.get_state()

        self.fsm.update(
            start=self.pending_start,
            stop=self.pending_stop
        )

        if self.fsm.running:
            self.counter.tick()

        self.clock.rising_edge()
        self.clear_inputs()

        return self.get_state()

    def clear_inputs(self):
        self.pending_start = False
        self.pending_stop = False
        self.pending_reset = False

    @property
    def state(self):
        return self.fsm.state

    @property
    def display(self):
        return self.counter.display()

    @property
    def running(self):
        return self.fsm.running

    def get_time(self):
        return self.counter.get_time()

    def get_state(self):
        return {
            "FSM State": self.state.name,
            "Display": self.display,
            "Clock Cycle": self.clock.cycle,
            "Simulated Time": self.clock.time_seconds,
            "Running": self.running,
            "Counters": self.counter.state(),
        }
